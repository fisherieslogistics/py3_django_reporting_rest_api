#!/usr/bin/env python
import sys
from pyresttest import resttest
resttest.command_line_run(sys.argv[1:])
